from django.contrib import admin

# Register your models 

from CSE.models import Sudent

admin.site.register(Sudent)